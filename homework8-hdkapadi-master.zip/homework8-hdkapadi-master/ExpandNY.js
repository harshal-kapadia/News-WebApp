import React,{Component} from 'react';
import '../App.css';
import './Expand.css';
import ReactTooltip from 'react-tooltip';
// import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import Commentbox from './Commentbox.js';
// import {FaChevronDown,FaChevronUp} from 'react-icons/fa';
import {FacebookIcon,EmailIcon,TwitterIcon,EmailShareButton,
    FacebookShareButton,TwitterShareButton} from "react-share";
import {MdBookmarkBorder, MdBookmark} from 'react-icons/md';
import { IconContext } from "react-icons";
import Toggle from './Toggle.js';
import Full from './Full.js';
import Header from './Header.js';
import Loader from "./Loader.js";
import { ToastContainer, toast, Zoom } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { css } from 'glamor';

function check(p){
    try{
        var t = p[0].headline.main;
    }
    catch(err){
    }
    return t;
}

function checkdate(p){
    try{
        var d = p[0].pub_date.substring(0,10);
    }
    catch(err){
    }
    return d;
}

function checkabstract(p){
    try{
        var a = p[0].abstract;
    }
    catch(err){
    }
    return a;
}

function checklength(p){
    try{
       if (p[0].abstract.length > 800){
           return(
            <Toggle title = {checkabstract(p)}>
                <Full cont={checkabstract(p)} />
            </Toggle>
           );
       }
       else{
           return(p[0].abstract);
       }
    }
    catch(err){
    }
}

function imgurl(p){
    //console.log("*******");
    //console.log(p);
    var temp;
    var i;
    var data = p[0].multimedia;
    try{
        for (i=0;i<data.length;i++)
        {
            if (data[i].width >=2000)
            {
                temp ="https://www.nytimes.com/" + data[i].url;
                break;
            }
         }
        if(temp.length == 0)
        temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg";
}
    catch{
        temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg";
    }
    
    return temp;
}

function appendS(p){
    if (p == 'SPORT')
    {
        p = p + 'S';
    }
    return p;
}

export default class Expand extends React.Component{
    constructor(props){
      super(props);
      
      this.addtobk = this.addtobk.bind(this);
      this.Deletefrombk = this.Deletefrombk.bind(this);
      this.isbookmarked = this.isbookmarked.bind(this);
      this.state = {
          error : null,
          isLoaded : false,
          posts : []        
      };
  }

  addtobk(post) {
    
    var lsarr = JSON.parse(localStorage.getItem('lsarr'));
    //console.log(lsarrobj);

    //post["hk_source"] = "nytimes";
    // var lsarrobj = post;
    //console.log(lsarrobj);
    var newdata = post[0]
    newdata["hk_source"] = "nytimes";
    //console.log(newdata["hk_source"]);
    lsarr.push(newdata);
    //console.log(lsarr);
    //console.log(JSON.stringify(lsarr));
    localStorage.setItem('lsarr',JSON.stringify(lsarr));

    toast("Saving "+post[0].headline.main , {className:
        css({
            color: "#000000 !important"
        })
    });
    setTimeout(this.forceUpdate(),3000);
  }

  isbookmarked(post){
    var arr = JSON.parse(localStorage.getItem("lsarr"));
    for (let i = 0; i < arr.length; i++){
        console.log("inside loop***");
        if (post.hk_source == "guardian")
        {
            if (post.id == arr[i].id)
                return true;
        }
        else
        {
            if (post[0].uri == arr[i].uri)
            {
                return true;
            }
        }
    }
    return false;
  }

  Deletefrombk(p)
  {
      //this.setState({bookmarkempty: !this.state.bookmarkempty})
      //console.log(p);
      var arr = JSON.parse(localStorage.getItem("lsarr"));
      //console.log(arr);
      var len1 = arr.length;
      var i;
      // console.log("p");
          for(let i=0;i<len1;i++)
          {
              //console.log(arr[i][0].uri);
              if(p.id){
                  if(p.id==arr[i].id){
                      arr.splice(i, 1);
                      //console.log("here inside");
                      break;
                  }
              }
              else if(p[0].web_url)
              {
                  //console.log("nytimes delete");
                  if(p[0].web_url==arr[i].web_url)
                  {
                      arr.splice(i, 1);
                      //console.log("here outside");
                      break;
                  }
              }
              else
              {
                  continue;
              }
          }
          
      localStorage.setItem("lsarr",JSON.stringify(arr));
      //console.log(localStorage.getItem("lsarr"));
      var len2 = arr.length;
      if(p.id)
      toast("Removing "+p.webTitle , {className:
        css({
            color: "#000000 !important"
        })
    });
      else
      toast("Removing "+p[0].headline.main , {className:
        css({
            color: "#000000 !important"
        })
    });  

      setTimeout(this.forceUpdate(),3000);
      //this.checklen(len1,len2);
      return;
  }
  

  componentDidMount() {
    var ur = this.props.location.search.substring(1,);
    var url = "https://hw8-backend-273710.appspot.com/expandcardny";
    fetch(`${url}/${this.props.location.search}`)
    .then( response => response.json())
    .then(
        // handle the result
        (result) => {
            this.setState({
                isLoaded : true,
                post : result.data.response.docs
            });
        },

        // Handle error 
        (error) => {
            this.setState({
                isLoaded: true,
                error
            })
        },
    )
}
  
    render() {
      const {error, isLoaded, post} = this.state;
      const arr = ['#CSCI_571_NewsApp'];
      //console.log(post);
      if(error){
          return <div>Error in loading</div>
      }else if (!isLoaded) {
          return <div><Loader /></div>
      }else{
          return (
              <div>
                   <ToastContainer
                        position="top-center"
                        autoClose={3000}
                        hideProgressBar
                        newestOnTop
                        closeOnClick={false}
                        rtl={false}
                        pauseOnVisibilityChange={false}
                        draggable={false}
                        pauseOnHover={false}
                        className="toastclass"
                        transition={Zoom}                        
                    />
                  {    
                      <div className="expandresultbox">
                                <p style={{padding: "0px" ,margin: "0px", fontSize:"25px"}}><i>{check(post)}</i></p>
                                <p className="expcarddate" style={{marginTop:"0.5%"}}><i>{checkdate(post)}</i>
                                <span className="icons">
                                    <FacebookShareButton hashtag="#CSCI_571_NewsApp" url ={post[0].web_url} data-tip="Facebook">
                                    <FacebookIcon size={30} round  style={{cursor:"pointer"}} label="facebook"></FacebookIcon>
                                    </FacebookShareButton>
                                    <ReactTooltip className="expandfb" place="top" type="dark" effect="solid"/>
                                    <TwitterShareButton hashtags={arr} url ={post[0].web_url} data-tip="Twitter">
                                    <TwitterIcon size={30} round  style={{cursor:"pointer"}}></TwitterIcon>
                                    </TwitterShareButton>
                                    <ReactTooltip className="expandtw" place="top" type="dark" effect="solid"/>
                                    <EmailShareButton subject="#CSCI_571_NewsApp" data-tip="Email" url={post[0].web_url}>
                                    <EmailIcon size={30} round  style={{cursor:"pointer"}} ></EmailIcon>
                                    </EmailShareButton>
                                    <ReactTooltip className="expandem" place="top" type="dark" effect="solid"/>
                                </span>
                                <div className="bookmark" style={{cursor:"pointer"}}>
                                    {this.isbookmarked(post) ?
                                    <>
                                       <span onClick={() => this.Deletefrombk(post)}>
                                            <IconContext.Provider value={{ color: "red" }} >
                                            <MdBookmark className="bookmark-icon" size={30} data-tip="Bookmark"/>
                                            <ReactTooltip place="top" type="dark" effect="solid"/>
                                            </IconContext.Provider>
                                        </span> 
                                    </>
                                :
                                    <>
                                        <span onClick={() => this.addtobk(post)}>
                                            <IconContext.Provider value={{ color: "red" }} >
                                            <MdBookmarkBorder className="bookmark-icon" size={30} data-tip="Bookmark"/>
                                            <ReactTooltip className="expandbk" place="top" type="dark" effect="solid"/>
                                            </IconContext.Provider>
                                        </span>
                                    </>
                                }
                                </div>
                                </p>
                                <div className="expandimage" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                <div className="expanddescr">
                                    <p><span className="expandsdes">{checklength(post)}</span></p>
                                </div> 
                            </div>
                  }
                  <Commentbox id={this.props.location.search.substring(9,)}/>
              </div>
          );

      }
    }
}