import React, { Component } from "react";
import {FaChevronDown,FaChevronUp} from 'react-icons/fa';

export default class Full extends React.Component {	 
	render() {
		return (
			<div> 
                
                {this.props.cont} </div>
		);
	}
}