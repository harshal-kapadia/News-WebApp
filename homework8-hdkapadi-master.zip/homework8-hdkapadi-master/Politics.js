import React from 'react';
import Select from 'react-select';
import "./Layout.css";
import { Container, Row, Col, Badge, Media } from 'reactstrap';
import { MdShare } from "react-icons/md";
import Header from './Header.js';
import Modal from 'react-bootstrap/Modal';
import {FacebookIcon,EmailIcon,TwitterIcon,EmailShareButton,
    FacebookShareButton,TwitterShareButton} from "react-share";
import BounceLoader from "react-spinners/BounceLoader";
import Loader from "./Loader.js";
import MediaQuery from 'react-responsive';

function imgurl(p){
    try{
        var l = p.blocks.main.elements[0].assets.length;
        var temp = p.blocks.main.elements[0].assets[l-1].file
    }
    catch{
        temp = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png"
    }
    return temp;
}

function descr(p){
    //console.log(p);
        var data = p.blocks.body[0].bodyTextSummary.substring(0,560)+"...";
    return data;
}

function gdescrresponsive1(p){
    try{
        var des = p.blocks.body[0].bodyTextSummary.substring(0,170)+"...";
    }
    catch(err){
    }
    return des;
}

function gdescrresponsive2(p){
    try{
        var des = p.blocks.body[0].bodyTextSummary.substring(0,350)+"...";
    }
    catch(err){
    }
    return des;
}

function gdescrresponsive3(p){
    try{
        var des = p.blocks.body[0].bodyTextSummary.substring(0,115)+"...";
    }
    catch(err){
    }
    return des;
}

function linktoexpand(p){
    var endpoint = "/expandcard?article="+p+"?";
    return endpoint;
}

function linktoexpandnyt(pt){
    var endpoint = "/expandcardny?id="+pt.url;
    return endpoint;
}

function retdatenyt(p){
    var display = p.substring(0,10);
    //console.log(display);
    return display;
}

function imgurl2(p)
{
    //console.log(p.section);
    var i;
    var temp="";
    var data = p.multimedia;
    try
    {
        for (i=0;i<data.length;i++)
        {
            if (data[i].width >=2000)
            {
                temp = p.multimedia[i].url;
            }
        }
        if(temp.length == 0)
        temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg";
    }
    catch
    {
        temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg"
    }
    return temp;
}

function sectionname(p){
    return "POLITICS";
}

function Example (props) {
    const [show, setShow] = React.useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    var t = props.data.webTitle;
    var u = props.data.webUrl;
    const arr=['CSCI_571_NewsApp'];
    return (
        <>
        
        <MdShare size={18} onClick={handleShow}></MdShare>
        <Modal show={show} onHide = {handleClose} >
        <Modal.Header closeButton>
            <Modal.Title className="modaltitle">{t}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <span className="share">Share Via<br /></span>
        <div style={{display:"flex",justifyContent:"space-between"}}>
        <FacebookShareButton url={u} quote={t} hashtag="#CSCI_571_NewsApp">
        <FacebookIcon round ></FacebookIcon>
        </FacebookShareButton>
        <TwitterShareButton url={u} quote={t} hashtags={arr}>
        <TwitterIcon round ></TwitterIcon>
        </TwitterShareButton>
        <EmailShareButton url={u} quote={t} subject="#CSCI_571_NewsApp">
        <EmailIcon round  url={u}></EmailIcon>
        </EmailShareButton>
        </div>
        </Modal.Body>
        </Modal>
        </>
    );
}

function Example2 (props) {
    const [show, setShow] = React.useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    var t = props.data.title;
    var u = props.data.url;
    const arr=['CSCI_571_NewsApp'];
    return (
        <>
        
        <MdShare size={18} onClick={handleShow}></MdShare>
        <Modal show={show} onHide = {handleClose}>
        <Modal.Header closeButton>
            <Modal.Title className='modaltitle'>{t}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <span className="share">Share Via<br /></span>
        <div style={{display:"flex",justifyContent:"space-between"}}>
        <FacebookShareButton url={u} quote={t} hashtag="#CSCI_571_NewsApp">
        <FacebookIcon round ></FacebookIcon>
        </FacebookShareButton>
        <TwitterShareButton url={u} quote={t} hashtags={arr}>
        <TwitterIcon round ></TwitterIcon>
        </TwitterShareButton>
        <EmailShareButton url={u} quote={t} subject="#CSCI_571_NewsApp">
        <EmailIcon round  url={u}></EmailIcon>
        </EmailShareButton>
        </div>
        </Modal.Body>
        </Modal>
        </>
    );
}

export default class Business extends React.Component{
    constructor(props){
        super(props);
        this.news = this.news.bind(this);
        if (localStorage.getItem("switch_val") === null)
		localStorage.setItem("switch_val","true");
        this.state = {
            error : null,
            isLoaded : false,
            source : localStorage.getItem("switch_val"),
            posts : []        
        };
    }

    getsource = (src) =>{
        this.setState({source:src});    
    }

    expandshare(evt){
        evt.preventDefault();
    }
    
    news()
    {
    var url;
    if(this.state.source === "false")
        {
            //console.log("inside nytimes");
            url = "https://hw8-backend-273710.appspot.com/politicsny";
            fetch(url)
            .then( response => response.json())
            .then(
                // handle the result
                (result) => {
                    this.setState({
                        isLoaded : true,
                        posts : result.data.results
                    });
                },

                // Handle error 
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    })
                },
            )
        }
        else
        {
            //console.log("inside gua");
            url = "https://hw8-backend-273710.appspot.com/politicsgu";
        
                fetch(url)
                .then( response => response.json())
                .then(
                    // handle the result
                    (result) => {
                        this.setState({
                            isLoaded : true,
                            posts : result.data.response.results
                        });
                    },

                    // Handle error 
                    (error) => {
                        this.setState({
                            isLoaded: true,
                            error
                        })
                    },
                )
        }
        //setTimeout(this.forceUpdate(),3000);
    }

  componentDidMount() {
    this.news();
        
}

    componentDidUpdate(prevState, prevProps)
    {
        var url;
        if(this.state.source !== prevProps.source)
        {
            if(this.state.source === "false")
            {
                url = "https://hw8-backend-273710.appspot.com/politicsny";
                fetch(url)
                .then( response => response.json())
                .then(
                    // handle the result
                    (result) => {
                        this.setState({
                            isLoaded : true,
                            posts : result.data.results
                        });
                    },

                    // Handle error 
                    (error) => {
                        this.setState({
                            isLoaded: true,
                            error
                        })
                    },
                )
            }
            else
            {
                url = "https://hw8-backend-273710.appspot.com/politicsgu";
                fetch(url)
                .then( response => response.json())
                .then(
                    // handle the result
                    (result) => {
                        this.setState({
                            isLoaded : true,
                            posts : result.data.response.results
                        });
                    },

                    // Handle error 
                    (error) => {
                        this.setState({
                            isLoaded: true,
                            error
                        })
                    },
                )
            }
        }
    }

    render() {
        const {error, isLoaded, posts} = this.state;
        if(error){
            return <div>Error in loading</div>
        }else if (!isLoaded) {
            return <div><Loader/></div>
        }else if (this.state.source === "true")
        {
            return(
                <div>
                    <MediaQuery minDeviceWidth={1025}>
                    {
                        posts.map(post => (
                            <a href={linktoexpand(post.id)}>
                                <div className="resultbox">
                                    <div className="image" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                    <div className="descr">
                                        <p style={{adding: "0px" ,margin: "0px"}}><i><b className="newstitle">{post.webTitle}</b></i><span onClick={this.expandshare}><Example data= {post} /></span></p>
                                        <span className="sdes">{descr(post)}{"\n"}</span>
                                        </div>
                                        <div className="outer">
                                        <span className="section">
                                            {/* { var temp = badgecolor(post.sectionId.toUpperCase())} */}
                                            <Badge className={post.sectionId.toUpperCase()}>{post.sectionId.toUpperCase()}</Badge>
                                            </span><p className="carddate" style={{marginTop:"1.5%"}}><i>{post.webPublicationDate.substring(0,10)}</i></p>
                                        <p></p>                                     
                                    </div> 
                                </div>
                            </a>
                        ))
                    }
                    </MediaQuery>
                    <MediaQuery minDeviceWidth={561} maxDeviceWidth={1024}>
                    {
                        posts.map(post => (
                            <a href={linktoexpand(post.id)}>
                                <div className="resultbox">
                                    <div className="image" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                    <div className="descr">
                                        <p style={{adding: "0px" ,margin: "0px"}}><i><b className="newstitle">{post.webTitle}</b></i><span onClick={this.expandshare}><Example data= {post} /></span></p>
                                        <span className="sdes">{gdescrresponsive2(post)}{"\n"}</span>
                                        </div>
                                        <div className="outer">
                                        <span className="section">
                                            {/* { var temp = badgecolor(post.sectionId.toUpperCase())} */}
                                            <Badge className={post.sectionId.toUpperCase()}>{post.sectionId.toUpperCase()}</Badge>
                                            </span><p className="carddate" style={{marginTop:"1.5%"}}><i>{post.webPublicationDate.substring(0,10)}</i></p>
                                        <p></p>                                     
                                    </div> 
                                </div>
                            </a>
                        ))
                    }
                    </MediaQuery>
                    <MediaQuery minDeviceWidth={321} maxDeviceWidth={560}>
                    {
                        posts.map(post => (
                            <a href={linktoexpand(post.id)}>
                                <div className="resultbox">
                                    <div className="image" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                    <div className="descr">
                                        <p style={{adding: "0px" ,margin: "0px"}}><i><b className="newstitle">{post.webTitle}</b></i><span onClick={this.expandshare}><Example data= {post} /></span></p>
                                        <span className="sdes">{gdescrresponsive1(post)}{"\n"}</span>
                                        </div>
                                        <div className="outer">
                                        <span className="section">
                                            {/* { var temp = badgecolor(post.sectionId.toUpperCase())} */}
                                            <Badge className={post.sectionId.toUpperCase()}>{post.sectionId.toUpperCase()}</Badge>
                                            </span><p className="carddate" style={{marginTop:"1.5%"}}><i>{post.webPublicationDate.substring(0,10)}</i></p>
                                        <p></p>                                     
                                    </div> 
                                </div>
                            </a>
                        ))
                    }
                    </MediaQuery>
                    <MediaQuery maxDeviceWidth={320}>
                    {
                        posts.map(post => (
                            <a href={linktoexpand(post.id)}>
                                <div className="resultbox">
                                    <div className="image" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                    <div className="descr">
                                        <p style={{adding: "0px" ,margin: "0px"}}><i><b className="newstitle">{post.webTitle}</b></i><span onClick={this.expandshare}><Example data= {post} /></span></p>
                                        <span className="sdes">{gdescrresponsive3(post)}{"\n"}</span>
                                        </div>
                                        <div className="outer">
                                        <span className="section">
                                            {/* { var temp = badgecolor(post.sectionId.toUpperCase())} */}
                                            <Badge className={post.sectionId.toUpperCase()}>{post.sectionId.toUpperCase()}</Badge>
                                            </span><p className="carddate" style={{marginTop:"1.5%"}}><i>{post.webPublicationDate.substring(0,10)}</i></p>
                                        <p></p>                                     
                                    </div> 
                                </div>
                            </a>
                        ))
                    }
                    </MediaQuery>
                </div>
            );
        }
        else
        {
            return (
                <div>
                    {/* <Header callback={this.getsource} /> */}
                    {
                        posts.slice(0,10).map(post => (
                            
                            <a href={linktoexpandnyt(post)}>
                                <div className="resultbox">
                                    <div className="image" ><img src={imgurl2(post)} style={{width:"100%"}} /></div>
                                    <div className="descr">
                {/* <p style={{adding: "0px" ,margin: "0px"}}><i><b className="newstitle">{post.webTitle}</b></i><Example data= {post.webTitle} /></p> */}
                                    <p style={{adding: "0px" ,margin: "0px"}}><i><b className="newstitle">{post.title}</b></i>
                                        <span onClick={this.expandshare}><Example2 data= {post} /></span>
                                    </p>
                                    <span className="sdes">{post.abstract}{"\n"}</span>
                                    </div>
                                    <div className="outer">
                                    <span className="section">
                                    {/* { var temp = badgecolor(post.sectionId.toUpperCase())} */}
                                    <Badge className="POLITICS">{sectionname(post.section)}</Badge>
                                    </span><p className="carddate" style={{marginTop:"1.5%"}}><i>{retdatenyt(post.published_date)}</i></p>
                                <p></p>                                     
                            </div> 
                        </div>
                            </a>
                        ))
                    }
                </div>
            );
        }    
    }
    }