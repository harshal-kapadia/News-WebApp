import React,{Component} from 'react';
import '../App.css';
import './Expand.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {FaChevronDown,FaChevronUp} from 'react-icons/fa';


export default class Toggle extends React.Component{
    constructor(props) {
		super(props);
		this.state = {
			opened: false,
		};
		this.toggleBox = this.toggleBox.bind(this);
	}
  
	toggleBox() {
		const { opened } = this.state;
		localStorage.setItem("bookmark_val", "false");
		this.setState({
			opened: !opened,
		});
	}
  
	render() {
		var { title, children } = this.props;
		const { opened } = this.state;
		if (localStorage.getItem("bookmark_val") == "false"){
			if (opened){
				setTimeout(() => window.scrollTo({top: 10000, left: 0, behavior: 'smooth'}),1)
				// title =<FaChevronUp size={15} style={{cursor:"pointer"}}></FaChevronUp>;
			}else{
				setTimeout(() => window.scrollTo({top: 0, left: 0, behavior: 'smooth'}),1)
				// title =<FaChevronDown size={15} style={{cursor:"pointer"}} onClick={}></FaChevronDown>;
			}
		}

		return (
			<div className="box">
				{opened && (
                					
					<div class="boxContent">
						{children}
					</div>
				)}
                <div className="boxTitle" onClick={this.toggleBox}>
					{(opened)? <FaChevronUp size={15} style={{cursor:"pointer"}}></FaChevronUp>: <FaChevronDown size={15} style={{cursor:"pointer"}}></FaChevronDown>}
				</div>
                {/* <FaChevronDown size={15}></FaChevronDown> */}
			</div>
		);
	}
}
