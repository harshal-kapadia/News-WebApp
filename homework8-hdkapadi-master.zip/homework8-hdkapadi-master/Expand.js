import React,{Component} from 'react';
import ReactTooltip from 'react-tooltip';
import '../App.css';
import './Expand.css';
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import Commentbox from './Commentbox.js';
import {FaChevronDown,FaChevronUp} from 'react-icons/fa';
import {FacebookIcon,EmailIcon,TwitterIcon,EmailShareButton,
    FacebookShareButton,TwitterShareButton} from "react-share";
import {MdBookmarkBorder, MdBookmark} from 'react-icons/md';
import { IconContext } from "react-icons";
import Toggle from './Toggle.js';
import Full from './Full.js';
import Header from './Header.js';

import { ToastContainer, toast, Zoom } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Loader from "./Loader.js";
import { css } from 'glamor';


function imgurl(p){
    try{
        var l = p.blocks.main.elements[0].assets.length;
        var temp = p.blocks.main.elements[0].assets[l-1].file
    }
    catch{
        temp = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png"
    }
    return temp;
}

function appendS(p){
    if (p == 'SPORT')
    {
        p = p + 'S';
    }
    return p;
}

function checklength(p){
    try{
        if (p.blocks.body[0].bodyTextSummary.length > 800)
        return true;
        else 
        return false;
    }
    catch(err){
    }
}

// function checksummary(p){
//     var data;
//     try{
//         data = p.blocks.body[0].bodyTextSummary;
//     }
//     catch(err){
//     }
//     return data;
// }

// function checklength(p){
//     try{
//         if (p.blocks.body[0].bodyTextSummary.length > 800){
//             return(
//                 <Toggle title = {checksummary(p)}>
//                 <Full cont={checksummary(p)} />
//             </Toggle>
//                );
//         }
//         else{
//             return(p.blocks.body[0].bodyTextSummary);
//         }
//     }
//     catch(err){
//     }
// }

export default class Expand extends React.Component{
  constructor(props){
    super(props);
    this.state = {
        error : null,
        isLoaded : false,
        posts : [],
        bookmarkfill :false,
        bookmarkempty : false
                
    };
    localStorage.setItem("bookmark_val", "false");
    this.addtobk = this.addtobk.bind(this);
    this.Deletefrombk = this.Deletefrombk.bind(this);
    this.isbookmarked = this.isbookmarked.bind(this);
}

addtobk(post) {
    //this.setState({bookmarkfill:!this.state.bookmarkfill})
    localStorage.setItem("bookmark_val", "true");
    var lsarr = JSON.parse(localStorage.getItem('lsarr'));
    //console.log(this.state.bookmarkfill);
    post["hk_source"] = "guardian";
    var lsarrobj = post;
    //console.log(post);

    lsarr.push(lsarrobj);
    localStorage.setItem('lsarr',JSON.stringify(lsarr));

    toast("Saving "+post.webTitle , {className:
        css({
            color: "#000000 !important"
        })
    });
    //toast.success({position:toast.POSITION.TOP_CENTER});
    this.forceUpdate();  
}

    isbookmarked(post)
    {
        //console.log(post);
        var arr = JSON.parse(localStorage.getItem("lsarr"));
        for (let i = 0; i < arr.length; i++){
            if (post.id){
                //console.log("inside bkmkd");
                if (post.id == arr[i].id)
                    return true;
            }
            else{
                //console.log("inside else bkmkd");
                if (post.uri == arr[i].uri)
                    return true;
            }
        }
        return false;
    }

    Deletefrombk(p)
    {
        localStorage.setItem("bookmark_val", "true");
        //this.setState({bookmarkempty: !this.state.bookmarkempty})
        //console.log(p);
        var arr = JSON.parse(localStorage.getItem("lsarr"));
        //console.log(arr);
        var len1 = arr.length;
        var i;
        // console.log("p");
            for(let i=0;i<len1;i++)
            {
                //console.log(arr[i][0].uri);
                if(p.id){
                    if(p.id==arr[i].id){
                        arr.splice(i, 1);
                        //console.log("here inside");
                        break;
                    }
                }
                else if(p.web_url)
                {
                    //console.log("nytimes delete");
                    if(p.web_url==arr[i].web_url)
                    {
                        arr.splice(i, 1);
                        //console.log("here outside");
                        break;
                    }
                }
                else
                {
                    continue;
                }
            }
            
        localStorage.setItem("lsarr",JSON.stringify(arr));
        //console.log(localStorage.getItem("lsarr"));
        var len2 = arr.length;
        if(p.id)
        toast("Removing "+p.webTitle , {className:
            css({
                color: "#000000 !important"
            })
        });
        else
        toast("Removing "+p.headline.main , {className:
            css({
                color: "#000000 !important"
            })
        });  

        setTimeout(this.forceUpdate(),3000);
        //this.checklen(len1,len2);
        return;
    }

componentDidMount() {
    var url = "https://hw8-backend-273710.appspot.com/expandcard";
    fetch(`${url}/${this.props.location.search}`)
    .then( response => response.json())
    .then(
        // handle the result
        (result) => {
            //console.log(result);
            this.setState({
                isLoaded : true,
                post : result.data.response.content
            });
        },

        // Handle error 
        (error) => {
            //console.log(error)
            this.setState({
                isLoaded: true,
                error
            })
        },
    )
}

  render() {
      //console.log(window.innerHeight);
    const {error, isLoaded, post} = this.state;
    const arr = ['#CSCI_571_NewsApp'];
    //var u = post.webUrl;
    const len = this.props.location.search.length;
    //console.log(this.props.location.search.substring(9,len-1));
    if(error){
        return <div>Error in loading</div>
    }else if (!isLoaded) {
        return <div>< Loader /></div>
    }else{
        return(
            <div>
                {/* <ToastContainer position="top-center"
                    autoClose={3000}
                    hideProgressBar
                    newestOnTop
                    closeOnClick={false}
                    rtl={false}
                    pauseOnVisibilityChange
                    draggable={false}
                    pauseOnHover={false}
                      /> */}
                    <ToastContainer
                        position="top-center"
                        autoClose={3000}
                        hideProgressBar
                        newestOnTop
                        closeOnClick={false}
                        rtl={false}
                        pauseOnVisibilityChange={false}
                        draggable={false}
                        pauseOnHover={false}
                        className="toastclass"
                        transition={Zoom}                        
                    />
                {   
                            <div className="expandresultbox">
                                <p style={{padding: "5px" ,margin: "0px", fontSize:"25px"}}><i>{post.webTitle}</i></p>
                                <p className="expcarddate" style={{marginTop:"0.5%"}}><i>{post.webPublicationDate.substring(0,10)}</i>
                                <span className="icons">
                                    <FacebookShareButton url={post.webUrl} hashtag="#CSCI_571_NewsApp" data-tip="Facebook">
                                    <FacebookIcon size={30}  round  style={{cursor:"pointer"}}></FacebookIcon>
                                    </FacebookShareButton>
                                    <ReactTooltip className="expandfb" place="top" type="dark" effect="solid"/>
                                    <TwitterShareButton url={post.webUrl} hashtags={arr} data-tip="Twitter">
                                    <TwitterIcon size={30}  round  style={{cursor:"pointer"}}></TwitterIcon>
                                    </TwitterShareButton>
                                    <ReactTooltip className="expandtw" place="top" type="dark" effect="solid"/>
                                    <EmailShareButton subject="#CSCI_571_NewsApp" data-tip="Email" url={post.webUrl}>
                                    <EmailIcon size={30} round  style={{cursor:"pointer"}} ></EmailIcon>
                                    </EmailShareButton>
                                    <ReactTooltip className="expandem" place="top" type="dark" effect="solid"/>
                                </span>
                                <div className="bookmark" style={{cursor:"pointer"}}>
                                    {this.isbookmarked(post) ?
                                    <>
                                    <span onClick={() => this.Deletefrombk(post)}>
                                        <IconContext.Provider value={{ color: "red" }}>
                                            <MdBookmark className="bookmark-icon-expand" size={30} data-tip="Bookmark"/>
                                            <ReactTooltip className="expandbk" place="top" type="dark" effect="solid"/>
                                        </IconContext.Provider>
                                    </span>
                                    </>
                                    :
                                    <>
                                    <span onClick={() => this.addtobk(post)}>
                                        <IconContext.Provider value={{ color: "red" }}>
                                            <MdBookmarkBorder className="bookmark-icon" size={30} data-tip="Bookmark"/>
                                            <ReactTooltip className="expandbk" place="top" type="dark" effect="solid"/>
                                        </IconContext.Provider>
                                    </span>
                                    </>
                                    }
                                </div>
                                </p>
                                <div className="expandimage" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                <div className="expanddescr">
                                {checklength(post)?
                                <>
                                    <p style={{marginBottom:"0px"}}>
                                        <span className="expandsdes">{post.blocks.body[0].bodyTextSummary.substring(0,800)}</span>
                                    </p>
                                    <Toggle title = {post.blocks.body[0].bodyTextSummary}>
                                        <Full cont={post.blocks.body[0].bodyTextSummary.substring(800)} />
                                    </Toggle>
                                    </>
                                : 
                                <>
                                    <p style={{marginBottom:"0px"}}>
                                        <span className="expandsdes">{post.blocks.body[0].bodyTextSummary.substring(0,800)}</span>
                                    </p>
                                </>
                                    }
                                </div> 
                            </div>
                    
                }
                <Commentbox id={this.props.location.search.substring(9,len-1)}/>
            </div>
        );
    }    
}
}