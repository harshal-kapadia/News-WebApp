import React from 'react';
import Select from 'react-select';
//import logo from './logo.svg';
import './Bookmark.css';
import { ToastContainer, toast, Zoom } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Header from './Header.js';
import { MdShare,MdDelete } from "react-icons/md";
import Modal from 'react-bootstrap/Modal';
import { Container, Row, Col, Badge } from 'reactstrap';
import {FacebookIcon,EmailIcon,TwitterIcon,EmailShareButton,
    FacebookShareButton,TwitterShareButton} from "react-share";
import { css } from 'glamor';

    function imgurl(p){
        try{
            var l = p.blocks.main.elements[0].assets.length;
            var temp = p.blocks.main.elements[0].assets[l-1].file
        }
        catch{
            temp = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png"
        }
        return temp;
    }
    
    function imgurl2(p)
    {
        var i;
        var temp="";
        var data = p.multimedia;
        //console.log(p);

        //console.log(data);
        try
        {
            for (i=0;i<data.length;i++)
            {
                if (data[i].width >=2000)
                {
                    temp = "https://www.nytimes.com/" + p.multimedia[i].url;
                    //console.log(temp+"***");
                }
            }
            if(temp.length == 0)
            temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg";
        }
        catch
        {
            temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg"
        }
        return temp;
    }

    function appendSg(p)
    {
        try{
            var dummy = p.sectionId.toUpperCase();
        if (dummy == 'SPORT')
        {
            dummy = dummy + 'S';
        }
    }
    catch(err){
    }
        return dummy;
    }

    function checknews(data) 
    {
        var st = "NYTIMES";
        if (data == "guardian")
        return data.toUpperCase();
        else
        return st;      
    }

function checknewsny(data) 
{
    var st = "NYTIMES";
    return st;      
}

function linktoexpand(p){
    var endpoint;
    if (p.hk_source == "guardian")
    {
        endpoint = "/expandcard?article="+p.id+"?";
        return endpoint;
    }
    else{
        endpoint = "/expandcardny?id="+p.web_url;
        return endpoint;
    }
}

// function linktoexpandnyt(pt){
//     var endpoint = "/Expandcardny?"+pt.web_url;
//     return endpoint;
// }


function Example (props) {
    var type = 'GUARDIAN';
    const [show, setShow] = React.useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    var t = props.data.webTitle;
    var u = props.data.webUrl;
    const arr=['CSCI_571_NewsApp'];
    return (
        <>
        
        <MdShare size={18} onClick={handleShow}></MdShare>
        <Modal show={show} onHide = {handleClose} >
        <Modal.Header closeButton>
            <Modal.Title className="modaltitle">{type}<br />
            {t}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <span className="share">Share Via<br /></span>
        <div style={{display:"flex",justifyContent:"space-between"}}>
        <FacebookShareButton url={u} quote={t} hashtag="#CSCI_571_NewsApp">
        <FacebookIcon round ></FacebookIcon>
        </FacebookShareButton>
        <TwitterShareButton url={u} quote={t} hashtags={arr}>
        <TwitterIcon round ></TwitterIcon>
        </TwitterShareButton>
        <EmailShareButton url={u} quote={t} subject="#CSCI_571_NewsApp">
        <EmailIcon round  url={u}></EmailIcon>
        </EmailShareButton>
        </div>
        </Modal.Body>
        </Modal>
        </>
    );
}

function Example2 (props) {
    //console.log(props);
    var type = "NYTIMES";
    const [show, setShow] = React.useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    var t = props.data.headline.main;
    var u = props.data.url;
    const arr=['CSCI_571_NewsApp'];
    return (
        <>
        
        <MdShare size={18} onClick={handleShow}></MdShare>
        <Modal show={show} onHide = {handleClose}>
        <Modal.Header closeButton>
            <Modal.Title className='modaltitle'>{type}<br />
            {t}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <span className="share">Share Via<br /></span>
        <div style={{display:"flex",justifyContent:"space-between"}}>
        <FacebookShareButton url={u} quote={t} hashtag="#CSCI_571_NewsApp">
        <FacebookIcon round ></FacebookIcon>
        </FacebookShareButton>
        <TwitterShareButton url={u} quote={t} hashtags={arr}>
        <TwitterIcon round ></TwitterIcon>
        </TwitterShareButton>
        <EmailShareButton url={u} quote={t} subject="#CSCI_571_NewsApp">
        <EmailIcon round url={u}></EmailIcon>
        </EmailShareButton>
        </div>
        </Modal.Body>
        </Modal>
        </>
    );
}

export default class Bookmark extends React.Component{
    constructor(props){
        super(props);
        this.expandshare = this.expandshare.bind(this);
        this.Deletefrombk = this.Deletefrombk.bind(this);
        this.tempfunc = this.tempfunc.bind(this);
        this.retny = this.retny.bind(this);
    }
    expandshare(evt){
        evt.preventDefault();
    }

    Deletefrombk(p)
    {
        //console.log(p);
        var arr = JSON.parse(localStorage.getItem("lsarr"));
        //console.log(arr);
        var len = arr.length;
        //console.log(len);
        var i;
        // console.log("p");
            for(let i=0;i<len;i++)
            {
                //console.log(arr[i][0].uri);
                if(p.hk_source == "guardian"){
                    if(p.id==arr[i].id){
                        arr.splice(i, 1);
                        //console.log("here inside");
                        break;
                    }
                }
                else if(p.hk_source == "nytimes")
                {
                    //console.log("nytimes delete");
                    if(p.web_url==arr[i].web_url)
                    {
                        //console.log(p[0].uri,"*******");
                        //console.log(i);
                        arr.splice(i, 1);
                        //console.log("here outside");
                        break;
                    }
                }
                else
                {
                    continue;
                }
            }
            
        localStorage.setItem("lsarr",JSON.stringify(arr));
        //console.log(localStorage.getItem("lsarr"));
        //console.log(arr.length);
        if(p.hk_source == "guardian")
        toast("Removing "+p.webTitle , {className:
            css({
                color: "#000000 !important"
            })
        });
        else
        toast("Removing "+p.headline.main , {className:
            css({
                color: "#000000 !important"
            })
        });  

        setTimeout(() => {this.forceUpdate()},1200);  
        return;
    }

    tempfunc(d){
        //console.log(d);
        var st = d.hk_source;
        //console.log(JSON.parse(localStorage.getItem("lsarr"))[0].id);
        if (st == "guardian")
        return true;
        else
        return false;
    }

    retny(){
        return "NYTIMES";
    }
    render(){
        var temps = JSON.parse(localStorage.getItem("lsarr"));
        //console.log("bookamarks", temps[0]);
        if (temps.length == 0){
            return (
                <div>
                    {/* <Header /> */}
                    <div style={{textAlign:"center",fontSize:"25px"}}>You have no saved articles.</div>
                </div>
            );
        }
        else {
        //console.log("here");
        return(
            <div>
                {/* <Header /> */}
                <ToastContainer
                        position="top-center"
                        autoClose={3000}
                        hideProgressBar
                        newestOnTop
                        closeOnClick={false}
                        rtl={false}
                        pauseOnVisibilityChange={false}
                        draggable={false}
                        pauseOnHover={false}
                        className="toastclass"
                        transition={Zoom}                        
                    />
                <div className="header">Favorites</div>
                {   
                            temps.map(temp => (
                                <a href={linktoexpand(temp)}>
                                <div className="bkresultbox">
                                {this.tempfunc(temp) ? 
                                <>
                                        <p style={{padding: "0px" ,margin: "0px"}}><i><b className="bknewstitle">{temp.webTitle}</b></i>
                                            <span onClick={this.expandshare}><Example data= {temp} /></span>
                                            {/* <span style={{display:"inline"}} onClick={this.Deletefrombk(temp)}> */}
                                                <span onClick={this.expandshare}><MdDelete size={18} onClick={this.Deletefrombk.bind(this,temp)}></MdDelete></span>
                                                {/* </span> */}
                                        </p>
                                        <div className="bkimage" ><img src={imgurl(temp)} style={{width:"100%"}} /></div>                               
                                        <div>
                                            <div className="bksection">
                                                <div style={{marginRight:"5%"}}><Badge className={appendSg(temp)}>{appendSg(temp)}</Badge></div>
                                                <div><Badge className={checknews(temp.hk_source)}>{checknews(temp.hk_source)}</Badge></div>
                                             </div>
                                            <div className="bkcarddate" style={{marginTop:"1.5%"}}><i>{temp.webPublicationDate.substring(0,10)}</i></div>
                                        </div>
                                </>
                               :
                               <>
                                    <p style={{padding: "0px" ,margin: "0px"}}><i><b className="bknewstitle">{temp.headline.main}</b></i>
                                        <span onClick={this.expandshare}><Example2 data= {temp} /></span> 
                                        <span onClick={this.expandshare}><MdDelete size={18} onClick={this.Deletefrombk.bind(this,temp)}></MdDelete></span>
                                    </p>
                                    <div className="bkimage" ><img src={imgurl2(temp)} style={{width:"100%"}} /></div>                               
                                    <div>
                                        <div className="bksection">
                                            <div style={{marginRight:"5%"}}> <Badge className={temp.section_name.toUpperCase()}>{temp.section_name.toUpperCase()}</Badge></div>
                                            <div><Badge className="NYTIMES">{this.retny()}</Badge></div>
                                         </div>
                                        <div className="bkcarddate" style={{marginTop:"1.5%"}}><i>{temp.pub_date.substring(0,10)}</i></div>
                                    </div>
                                </>
                                }
                               </div>
                               </a>
                            ))                       
                }
                
            </div>
        );
            }
}
}