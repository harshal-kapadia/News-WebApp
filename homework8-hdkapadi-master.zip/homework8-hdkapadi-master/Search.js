import React,{Component} from 'react';
import '../App.css';
import './Search.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Badge } from 'reactstrap';
import { MdShare } from "react-icons/md";
import Modal from 'react-bootstrap/Modal';
import {FacebookIcon,EmailIcon,TwitterIcon,EmailShareButton,
    FacebookShareButton,TwitterShareButton} from "react-share";
import Header from './Header.js';
import Loader from "./Loader.js";

function imgurl(p){
    try{
        var l = p.blocks.main.elements[0].assets.length;
        var temp = p.blocks.main.elements[0].assets[l-1].file
    }
    catch{
        temp = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png"
    }
    return temp;
}

function imgurl2(p)
{
    var temp;
    var i;
    var data = p.multimedia;
    try
    {
        for (i=0;i<data.length;i++)
        {
            if (data[i].width >=2000)
            {
                temp ="https://www.nytimes.com/" + data[i].url;
                break;
            }

        }
        if(temp.length == 0)
        temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg";
    }
    catch
    {
        temp = "https://upload.wikimedia.org/wikipedia/commons/0/0e/Nytimes_hq.jpg";
    }
    
    return temp;
}

function Example (props) {
    const [show, setShow] = React.useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    var t = props.data.webTitle;
    var u = props.data.webUrl;
    const arr=['CSCI_571_NewsApp'];
    return (
        <>
        
        <MdShare size={18} onClick={handleShow}></MdShare>
        <Modal show={show} onHide = {handleClose} >
        <Modal.Header closeButton>
            <Modal.Title className="modaltitle">{t}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <span className="share">Share Via<br /></span>
        <div style={{display:"flex",justifyContent:"space-between"}}>
        <FacebookShareButton url={u} quote={t} hashtag="#CSCI_571_NewsApp">
        <FacebookIcon round ></FacebookIcon>
        </FacebookShareButton>
        <TwitterShareButton url={u} quote={t} hashtags={arr}>
        <TwitterIcon round ></TwitterIcon>
        </TwitterShareButton>
        <EmailShareButton url={u} quote={t} subject="#CSCI_571_NewsApp">
        <EmailIcon round  url={u}></EmailIcon>
        </EmailShareButton>
        </div>
        </Modal.Body>
        </Modal>
        </>
    );
}

function Example2 (props) {
    const [show, setShow] = React.useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    var t = props.data.title;
    var u = props.data.url;
    const arr=['CSCI_571_NewsApp'];
    return (
        <>
        
        <MdShare size={18} onClick={handleShow}></MdShare>
        <Modal show={show} onHide = {handleClose}>
        <Modal.Header closeButton>
            <Modal.Title className='modaltitle'>{t}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <span className="share">Share Via<br /></span>
        <div style={{display:"flex",justifyContent:"space-between"}}>
        <FacebookShareButton url={u} quote={t} hashtag="#CSCI_571_NewsApp">
        <FacebookIcon round ></FacebookIcon>
        </FacebookShareButton>
        <TwitterShareButton url={u} quote={t} hashtags={arr}>
        <TwitterIcon round ></TwitterIcon>
        </TwitterShareButton>
        <EmailShareButton url={u} quote={t} subject="#CSCI_571_NewsApp">
        <EmailIcon round  url={u}></EmailIcon>
        </EmailShareButton>
        </div>
        </Modal.Body>
        </Modal>
        </>
    );
}

function debug(p){
    //console.log(p.docs);
}

function linktoexpand(p){
    var endpoint = "/expandcard?article="+p+"?";
    return endpoint;
}

function linktoexpandnyt(pt){
    var endpoint = "/expandcardny?id="+pt.web_url;
    return endpoint;
}

export default class Layout extends React.Component{
  constructor(props){
    super(props);
    this.state = {
        error : null,
        isLoaded : false,
        posts : []        
    };
}

expandshare(evt){
    evt.preventDefault();
}

  componentDidMount() {
    var query = this.props.location.search;
    var init = query.substring(1,3);
    //console.log(query);
    var url = "https://hw8-backend-273710.appspot.com/search"+query;
    if (init == 'gu'){
    //  fetch("https://content.guardianapis.com/search?q=" +query.substring(3,)+ "&api-key=72fe3ad3-18c3-4f52-aa90-b0dc7b8a2a47&show-blocks=all")
    fetch(url)
    .then( response => response.json())
    .then(
        // handle the result
        (result) => {
            this.setState({
                isLoaded : true,
                posts : result.data.response.results
            });
        },

        // Handle error 
        (error) => {
            this.setState({
                isLoaded: true,
                error
            })
        },
    )
    }
    else{
        //console.log("inside else*************");
        var url = "https://hw8-backend-273710.appspot.com/search"+query;
        //console.log(url);
        fetch(url)
        .then( response => response.json())
        .then(
            // handle the result
            (result) => {
                this.setState({
                    isLoaded : true,
                    posts : result.data.response.docs
                });
            },

            // Handle error 
            (error) => {
                this.setState({
                    isLoaded: true,
                    error
                })
            },
        )
    }
}

componentDidUpdate(prevProps,prevState)
{
    var query = this.props.location.search;
    var init = query.substring(1,3);
    //console.log(query);
    if (this.props.location.search !== prevProps.location.search)
    {
        if (init == 'gu')
        {
            fetch("https://hw8-backend-273710.appspot.com/search"+query)
           .then( response => response.json())
           .then(
               // handle the result
               (result) => {
                   this.setState({
                       isLoaded : true,
                       posts : result.response.results
                   });
               },
       
               // Handle error 
               (error) => {
                   this.setState({
                       isLoaded: true,
                       error
                   })
               },
           )
        }
           else
           {
               //console.log("inside else*************");
               var url = "https://hw8-backend-273710.appspot.com/search" + query;
               //console.log(url);
               fetch(url)
               .then( response => response.json())
               .then(
                   // handle the result
                   (result) => {
                       this.setState({
                           isLoaded : true,
                           posts : result.response.docs
                       });
                   },
       
                   // Handle error 
                   (error) => {
                       this.setState({
                           isLoaded: true,
                           error
                       })
                   },
               )
           }
    }
}

  render() {
    const {error, isLoaded, posts} = this.state;
    const start = this.props.location.search.substring(1,3);
     if(error){
        return <div>Error in loading</div>
    }else if (!isLoaded) {
        return <div>< Loader /></div>
    }
    else if (posts.length == 0){
        return <div style={{textAlign:"center",fontSize:"25px"}}>No Results.</div>
    }
    else if(start == 'gu') {
        return(
            <div>
                {/* <Header /> */}
                <span style={{fontSize:"20px",marginLeft:"2%"}}>Results</span><br />
                {
                    posts.map(post => (
                        <a href={linktoexpand(post.id)}>
                            <div className="searchresultbox">
                                <p style={{padding: "0px" ,margin: "0px"}}><i><b className="searchnewstitle">{post.webTitle}</b></i>
                                <span onClick={this.expandshare}><Example data= {post} /></span></p>
                                <div className="searchimage" ><img src={imgurl(post)} style={{width:"100%"}} /></div>
                                <div>
                                    <div className="searchsection">
                                        <Badge className={post.sectionId.toUpperCase()}>{post.sectionId.toUpperCase()}</Badge>
                                    </div>
                                    <div className="searchcarddate" style={{marginTop:"1.5%"}}><i>{post.webPublicationDate.substring(0,10)}</i></div>
                                </div>
                            </div>
                        </a>
                    ))
                }
            </div>
        );
    }
    else{
        //console.log("here nytimes", posts);
        // posts = posts.response.docs;
        return(
            
            <div>
                {/* <Header /> */}
                <span style={{fontSize:"20px",marginLeft:"0.5%"}}>Results</span><br />
                {
                    posts.map( (post, key) => (
                        <a href={linktoexpandnyt(post)}>   
                            <div className="searchresultbox">
                                <p style={{padding: "0px" ,margin: "0px"}}><i><b className="searchnewstitle">{post.headline.main}</b></i>
                                <span onClick={this.expandshare}><Example2 data= {post} /></span></p>
                                <div className="searchimage" ><img src={imgurl2(post)} style={{width:"100%"}} /></div>
                                <div>
                                    <div className="searchsection">
                                        <Badge className={post.news_desk.toUpperCase()}>{post.news_desk.toUpperCase()}</Badge>
                                    </div>
                                        <div className="searchcarddate" style={{marginTop:"1.5%"}}><i>{post.pub_date.substring(0,10)}</i></div>
                                </div>
                            </div>
                        </a>
                    ))
                }
            </div>
        );
    }    
}
}