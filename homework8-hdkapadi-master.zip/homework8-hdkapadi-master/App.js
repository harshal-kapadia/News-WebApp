import React from 'react';
import Select from 'react-select';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from "./components/Header.js";
import Layout from "./components/Layout.js";
import {
	BrowserRouter as Router,
	Route,
  Link,
  Switch,
	useParams
  } from "react-router-dom";
  import {withRouter} from 'react-router';
  import World from "./components/World.js";
  import Search from "./components/Search.js";
  import Politics from "./components/Politics.js";
  import Business from "./components/Business.js";
  import Technology from "./components/Technology.js";
  import Sports from "./components/Sports.js";
  import Expand from './components/Expand.js';
  import ExpandNY from './components/ExpandNY.js';
  import NYT from './components/NYT.js';
  import Bookmark from './components/Bookmark.js';

  class App extends React.Component {
    constructor(props){
      super(props);
      if (localStorage.getItem("switch_val") === null)
		localStorage.setItem("switch_val","true");
      this.state ={
        source : localStorage.getItem("switch_val")  
      };

    }
    getsource = (src) =>{
  //console.log(src);
    this.setState({source:src});
}

  render(){
  return (
    <main>
      <Router>
        <div className="row" style={{ display: "inline", marginRight:"0px", marginLeft:"0px"}}>
        <Header callback={this.getsource}/>
        </div>
        <Switch>
            <Route exact path="/" component={() => <Layout data={this.state.source}/>}>
            </Route>
            <Route exact path="/world" component={() => <World data={this.state.source}/>}>
            </Route>
            <Route exact path="/politics" component={() => <Politics data={this.state.source}/>}>
            </Route>
            <Route exact path="/business" component={() => <Business data={this.state.source}/> }>
            </Route>
            <Route exact path="/tech" component={() => <Technology data={this.state.source}/>}>
            </Route>
            <Route exact path="/sports" component={() => <Sports data={this.state.source}/>}>
            </Route>
            <Route exact path="/search" component={Search}>
            </Route>
            <Route exact path="/expandcard" component={Expand}>
            </Route>
            <Route exact path="/expandcardny" component={ExpandNY}>
            </Route>
            <Route exact path="/nytimes" component={NYT}>
            </Route>
            <Route exact path="/bookmark" component={Bookmark}>
            </Route>
        </Switch>
      </Router>
    </main>
  );
  }
}

export default App;



