import React, { Fragment } from 'react';
import './Header.css';
import { Form,FormControl, Nav, NavItem, NavDropdown, MenuItem } from 'react-bootstrap/';
import Navbar from 'react-bootstrap/Navbar';
import Switch from 'react-switch';
import {FaRegBookmark,FaBookmark, FaBlackTie} from 'react-icons/fa';
import BounceLoader from "react-spinners/BounceLoader";
import { IconContext } from "react-icons";
import AsyncSelect from 'react-select/lib/Async';
import _ from 'lodash';
import {withRouter} from 'react-router';
import { NavLink,Link } from 'react-router-dom';
import ReactTooltip from 'react-tooltip';
import MediaQuery from 'react-responsive';

class Header extends React.Component{
  constructor() {
		super();
		// if (localStorage.getItem("switch_val") === null)
		// 	localStorage.setItem("switch_val","true");
		// console.log(localStorage.getItem("switch_val")=='false');
		this.hideswitch = this.hideswitch.bind(this);
		this.displayvalue = this.displayvalue.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.bookmarkicon = this.bookmarkicon.bind(this);
		this.checkhome = this.checkhome.bind(this);
		this.checkworld = this.checkworld.bind(this);
		this.state = {
			checked:  localStorage.getItem("switch_val")=="true"?true:false, 
			input_value:""
		};
	}

	checkhome = () =>{
		if (window.location.href.includes('/'))
		return true;
		else
		return false;
	}

	displayvalue = () => {
		if (window.location.href.toString().includes('/search'))
		return true;
		else
		return false;
	}

	hideswitch = () => {
		if (window.location.href.includes('/search'))
		return false;
		if (window.location.href.includes('/bookmark'))
		return false;
		if (window.location.href.toString().includes('/expandcard'))
		return false;
		return true;
	}

	handleChange = (checked) => {
		this.setState({ checked});
		var val;
		if (checked === true)
		val = 'true';
		else
		val = 'false';
		
		localStorage.setItem("switch_val",val);
		this.props.callback(val);
	}

	bookmarkicon = () => {
		if (window.location.href.includes('/bookmark'))
		return true;
		else
		return false;
	}

	searchChange = (option_data) => {
		this.setState({
			input_value:option_data.value
		},() => {
			//this.props.history.push('/search?'+optdata.value);
			//console.log(this.state.checked);
			if(this.state.checked.toString() === "true")
			{
				//console.log("search gu");
				this.props.history.push('/search?gu='+option_data.value);
			}
			else{
				//console.log("search ny");
				this.props.history.push('/search?ny='+option_data.value);
			}
		
		})
	}

	handleKeywordChange = (newValue) => {
		this.setState({newValue});
		return newValue;
	};

	checkworld = () => {
		if (window.location.href.includes('/world'))
		return true;
		else
		return false;
	}

	async getWords(input_value){
		if (!input_value){
			return [];
		}

		let urlstring = 'https://harshal-kapadia.cognitiveservices.azure.com/bing/v7.0/suggestions?q='+input_value;
		const reply = await fetch(urlstring,{
			headers: {
				'Ocp-Apim-Subscription-Key':'002f929c735f49ad84143ba5cee88a7f'
			}
		});
		let remove_options = [{ value:input_value,label:input_value }];
		const result = await reply.json();

		if(result.suggestionGroups !== null)
		{
			result.suggestionGroups[0].searchSuggestions.map((suggestion) =>{
				remove_options.push({value: suggestion.displayText,label:suggestion.displayText})
			})
			return remove_options;
		}
	}	

	render() {
		const custom = {
			color: "black",
		}
		return (
		<div >
			
			<Navbar collapseOnSelect expand="lg" bg="primary" collapseOnSelect={true} variant="dark" className="dark">
			<Navbar.Brand style={{color:"black"}}>
			{this.displayvalue() ?
			<>
				<AsyncSelect
				loadOptions = {this.getWords}
				noOptionsMessage = {() => "No Match"}
				onInputChange = {_.debounce(this.handleKeywordChange,1000)}
				onChange = {this.searchChange}
				// className = 'searchbar'
				style={custom}
				placeholder = 'Enter Keyword ..'
				className="searchnav"
				/>
			</>
			:
			<>
			<AsyncSelect
				value= {''}
				loadOptions = {this.getWords}
				noOptionsMessage = {() => "No Match"}
				onInputChange = {_.debounce(this.handleKeywordChange,1000)}
				onChange = {this.searchChange}
				// className = 'searchbar'
				style={custom}
				placeholder = 'Enter Keyword ..'
				className="searchnav"
				/>
			</>
			}
			</Navbar.Brand>
				<Navbar.Toggle aria-controls="responsive-navbar-nav" />
				<Navbar.Collapse id="responsive-navbar-nav">
					<Nav className="mr-auto">
							
							<ul className="navbar-ul">							
							<li><NavLink as={Link} to="/" activeClassName={"active"} exact={true} className="nav-link">Home</NavLink></li> 
							<li><NavLink as={Link} to="/world" activeClassName={"active"} exact={true} className="nav-link">World</NavLink></li>
							<li><NavLink as={Link} to="/politics" activeClassName={"active"} exact={true} className="nav-link">Politics</NavLink></li>
							<li><NavLink as={Link} to="/business" activeClassName={"active"} exact={true} className="nav-link">Business</NavLink></li>
							<li><NavLink as={Link} to="/tech" activeClassName={"active"} exact={true} className="nav-link">Technology</NavLink></li>
							<li><NavLink as={Link} to="/sports" activeClassName={"active"} exact={true} className="nav-link">Sports</NavLink></li>
							</ul>
					</Nav>
					<Nav>
						{this.bookmarkicon() ?
						<>
						<NavLink as={Link} to="/bookmark" style={{cursor:"default"}}>
							<IconContext.Provider value={{ color: "white" }}>
								<FaBookmark className="bookmark-icon" size={22}/>
							</IconContext.Provider>
						</NavLink>
						</> :
						<>
						<NavLink as={Link} to="/bookmark" style={{cursor:"default"}}>
							<IconContext.Provider value={{ color: "white" }}>
								<FaRegBookmark className="bookmark-icon" size={22} data-tip="Bookmark" data-for="navbk"/>
								<ReactTooltip className="hometooltip" place="bottom" type="dark" effect="solid" id="navbk"/>
							</IconContext.Provider>
						</NavLink>
						</>
						}
					</Nav>
					{ this.hideswitch() ?
					<>
					<Nav className="right">	
						<Nav.Link className="nylabel"><span style={{color:"white"}}>NY Times</span></Nav.Link>
						<label htmlFor="material-switch">
							<Switch
								checked={Boolean(this.state.checked)}
								onChange={this.handleChange}
								onColor="#008ee6"
								offColor="#ebebeb"
								onHandleColor="#ffffff"
								handleDiameter={20}
								uncheckedIcon={false}
								checkedIcon={false}
								boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
								activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
								height={20}
								width={48}
								className="react-switch"
								id="material-switch"
							/>
							
						</label>
						<Nav.Link className="gulabel"><span style={{color:"white"}}>Guardian</span></Nav.Link>
					</Nav>
					</>
					: null
					}
					
				</Navbar.Collapse>
			</Navbar>
			
		</div>)
	}
}

export default withRouter(Header);


