import React from 'react';
import BounceLoader from "react-spinners/BounceLoader";

export default class Loader extends React.Component{
    render(){
        return (
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <BounceLoader css="margin:0 auto"
                                size={40}
                                color="#123ABC" />
                                Loading
            </div>
        );
    }
}